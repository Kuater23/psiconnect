const express = require('express');
const admin = require('firebase-admin');
const bodyParser = require('body-parser');
const cors = require('cors'); // Importar el middleware cors

const app = express();
app.use(bodyParser.json());
app.use(cors()); // Usar el middleware cors

const serviceAccount = require('/psi-connect/backend/psiconnect-eb98a-firebase-adminsdk-tc9kl-220c7361e9.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://psiconnect-eb98a-default-rtdb.firebaseio.com'
});

// Endpoint para eliminar un usuario
app.post('/deleteUser', async (req, res) => {
  const uid = req.body.uid;
  console.log(`Received request to delete user with uid: ${uid}`); // Log para depuración

  try {
    // Eliminar el usuario de Firebase Authentication
    await admin.auth().deleteUser(uid);
    console.log(`User with uid: ${uid} deleted successfully from Authentication`); // Log para depuración

    // Eliminar el usuario de Firestore
    const db = admin.firestore();
    await db.collection('users').doc(uid).delete();
    console.log(`User with uid: ${uid} deleted successfully from Firestore`); // Log para depuración

    res.status(200).send({ message: 'Usuario eliminado exitosamente' });
  } catch (error) {
    console.error(`Error deleting user with uid: ${uid}`, error); // Log para depuración
    res.status(500).send({ message: 'Error al eliminar el usuario', error });
  }
});

// Endpoint para agregar un usuario
app.post('/addUser', async (req, res) => {
  const { email, password, displayName } = req.body;
  console.log(`Received request to add user with email: ${email}`); // Log para depuración

  try {
    const userRecord = await admin.auth().createUser({
      email,
      password,
      displayName,
    });

    // Agregar el usuario a Firestore
    const db = admin.firestore();
    await db.collection('users').doc(userRecord.uid).set({
      email,
      displayName,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log(`User with email: ${email} added successfully`); // Log para depuración
    res.status(200).send({ message: 'Usuario agregado exitosamente', uid: userRecord.uid });
  } catch (error) {
    console.error(`Error adding user with email: ${email}`, error); // Log para depuración
    res.status(500).send({ message: 'Error al agregar el usuario', error });
  }
});

// Endpoint para obtener la lista de usuarios
app.get('/users', async (req, res) => {
  try {
    const db = admin.firestore();
    const usersSnapshot = await db.collection('users').get();
    const users = usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.status(200).send(users);
  } catch (error) {
    console.error('Error getting users', error); // Log para depuración
    res.status(500).send({ message: 'Error al obtener los usuarios', error });
  }
});

// Iniciar el servidor
const port = 3000;
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});